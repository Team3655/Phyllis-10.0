This file instructs you on how to import "ST25AndroidDemoApp" project in Android Studio.

- Open Android Studio
- Click on File > Open 
	A dialog box will be opened. Select the "ST25AndroidDemoApp" folder on your File System.
	
	
	
	
	